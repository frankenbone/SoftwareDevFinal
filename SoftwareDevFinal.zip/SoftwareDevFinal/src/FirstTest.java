import static org.junit.Assert.assertFalse;

//First test class

import org.junit.Test;



public class FirstTest {
	@Test
	public void add() {
		assertFalse("This is failed by me",false);
		System.out.println("First test ===> PASSSED");
	}	
	
}



